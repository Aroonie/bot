ALTER TABLE users
  ADD permission_mask INT DEFAULT 0 NOT NULL;