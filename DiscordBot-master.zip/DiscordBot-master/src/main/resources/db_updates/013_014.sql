ALTER TABLE playlist
  ADD play_type INT(11) NOT NULL;